## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----eval = FALSE-------------------------------------------------------------
# # install.packages("remotes")
# remotes::install_github("EduVit/roadcrashVIC")

## -----------------------------------------------------------------------------
library(roadcrashVIC)

## -----------------------------------------------------------------------------
vic_crashes |>
  dplyr::select(accident_date, lga_name, severity) |>
  head(5)

## -----------------------------------------------------------------------------
crashes_2025 <- filter_crashes(vic_crashes, start_date = "2025-01-01", end_date = "2025-12-31")
range(crashes_2025$accident_date)
nrow(crashes_2025)

## -----------------------------------------------------------------------------
summarise_crashes(crashes_2025, by = "day_of_week")

## -----------------------------------------------------------------------------
crash_rates(vic_crashes, vic_population, by = "year") |>
  dplyr::select(year, crashes, population, crashes_per_100k)

## -----------------------------------------------------------------------------
summarise_vulnerable(vic_crashes) |>
  dplyr::select(road_user, crashes, ksi_per_1000_crashes)

## ----eval = FALSE-------------------------------------------------------------
# run_app()

