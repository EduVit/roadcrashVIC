#### How to use this app

**Victoria:** crashes across the state for the selected years, metric and scale. All charts and the map follow these selections.

**My area:** crashes in one or more local government areas (LGAs) for the selected months and road users, including the location of each crash on the map.

Maps can be zoomed and moved; hovering over an area or a crash shows a summary; clicking a crash shows its details.

#### Definitions

**Crash:** a road crash in which at least one person was injured or killed, as recorded by Victoria Police.

**KSI:** people killed or seriously injured.

**Per 1,000 crashes:** people killed or seriously injured (KSI), or killed (deaths), for every 1,000 crashes. It measures how severe crashes were.

**Per 100k residents:** yearly number of crashes, people killed or seriously injured (KSI), or deaths, for every 100,000 people living in the area.

**Compare with population growth:** option of the trend chart that shows the selected values and the population relative to the first selected year, set to 100. It compares crash trends with Victoria's strong population growth. It is not a standard road-safety measure.

#### Things to keep in mind

- Rates per resident include every crash within an area, including those involving visitors and through traffic.
- A lower rate per resident does not necessarily mean safer roads. Rates do not account for how much people drive and traffic fluxes.
- Roads with the most crashes are not necessarily the most dangerous. Busier roads have more crashes, and traffic volumes are not available in this analysis.
- Small areas and short periods have few crashes; their figures can vary considerably by chance.
- Crash numbers in 2020 and 2021 were affected by COVID-19 restrictions.
- Some crashes from late 2025 do not have a recorded location yet; these crashes count only in state-wide totals.
- Alpine resorts and islands not administered by a council are grouped as `Unincorporated Vic`. Their resident population is small compared with the number of visitors, and no rate is shown for them.

#### Future work

- **Updated data:** the app currently covers crashes up to December 2025. Future versions could update the data automatically and include the most recent crashes.
- **Traffic volumes:** a road with many crashes may simply be a road used by many cars. Adding the number of vehicles on each road would make it possible to compare roads fairly.

#### Data sources

[Victorian road crash data](https://discover.data.vic.gov.au/dataset/victoria-road-crash-data) - Department of Transport and Planning, CC BY 4.0.

[Regional population, 2024-25: estimated resident population by LGA](https://www.abs.gov.au/statistics/people/population/regional-population/2024-25) - Australian Bureau of Statistics, CC BY 4.0.

[Vicmap Admin: Local Government Area (LGA) polygon aligned to property](https://discover.data.vic.gov.au/dataset/vicmap-admin-local-government-area-lga-polygon-aligned-to-property) - Department of Transport and Planning, CC BY 4.0.
